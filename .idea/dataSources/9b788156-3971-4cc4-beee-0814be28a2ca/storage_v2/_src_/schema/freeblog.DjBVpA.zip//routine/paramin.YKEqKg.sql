create procedure ParamIn(IN likeParam varchar(43))
  BEGIN
	SELECT * FROM posts WHERE nome LIKE likeParam;
END;

